#define RAKNET_VERSION "3.25"

#define RAKNET_REVISION "$Revision$"

#define RAKNET_DATE "$Date$"
