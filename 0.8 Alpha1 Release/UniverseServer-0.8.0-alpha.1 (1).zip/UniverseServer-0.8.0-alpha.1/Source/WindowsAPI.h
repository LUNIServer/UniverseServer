#pragma once
#include "windows.h"

DWORD WINAPI GetCurrentProcessId(void);